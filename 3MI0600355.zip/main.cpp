#include <iostream>
#include "CommandLoop.h"

int main() {
    CommandLoop commandLoop;
    commandLoop.run();

    return 0;
}